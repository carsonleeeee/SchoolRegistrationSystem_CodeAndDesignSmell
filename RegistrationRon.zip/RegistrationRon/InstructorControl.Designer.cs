﻿namespace RegistrationRon
{
    partial class InstructorControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dropC = new System.Windows.Forms.Button();
            this.crn = new System.Windows.Forms.Label();
            this.studentidlb = new System.Windows.Forms.Label();
            this.submitid = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.fsnametb = new System.Windows.Forms.TextBox();
            this.streettb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.emailtb = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.officetb = new System.Windows.Forms.TextBox();
            this.ziptb = new System.Windows.Forms.TextBox();
            this.sidd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cnamelb = new System.Windows.Forms.Label();
            this.sfnamelb = new System.Windows.Forms.Label();
            this.streetlb = new System.Windows.Forms.Label();
            this.studidlb = new System.Windows.Forms.Label();
            this.officelb = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.citytb = new System.Windows.Forms.TextBox();
            this.slnametb = new System.Windows.Forms.TextBox();
            this.statetb = new System.Windows.Forms.TextBox();
            this.SectionLink = new System.Windows.Forms.LinkLabel();
            this.CoursesLink = new System.Windows.Forms.LinkLabel();
            this.Studentlink = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.Studentidcb = new System.Windows.Forms.ComboBox();
            this.ResetAllFields = new System.Windows.Forms.LinkLabel();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Studentidcb);
            this.groupBox4.Controls.Add(this.groupBox1);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.studentidlb);
            this.groupBox4.Controls.Add(this.submitid);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 28);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(276, 352);
            this.groupBox4.TabIndex = 28;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Search";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(8, 52);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(262, 137);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Schedule";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(7, 23);
            this.listBox1.Name = "listBox1";
            this.listBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox1.Size = new System.Drawing.Size(247, 100);
            this.listBox1.TabIndex = 9;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.dropC);
            this.groupBox5.Controls.Add(this.crn);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(8, 190);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(262, 153);
            this.groupBox5.TabIndex = 27;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Actions";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(41, 67);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 37);
            this.button2.TabIndex = 25;
            this.button2.Text = "Update Instructor";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(41, 24);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 37);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add Instructor";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dropC
            // 
            this.dropC.Location = new System.Drawing.Point(41, 110);
            this.dropC.Name = "dropC";
            this.dropC.Size = new System.Drawing.Size(153, 38);
            this.dropC.TabIndex = 24;
            this.dropC.Text = "Delete Instructor";
            this.dropC.UseVisualStyleBackColor = true;
            this.dropC.Click += new System.EventHandler(this.dropC_Click);
            // 
            // crn
            // 
            this.crn.AutoSize = true;
            this.crn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crn.Location = new System.Drawing.Point(19, 42);
            this.crn.Name = "crn";
            this.crn.Size = new System.Drawing.Size(0, 16);
            this.crn.TabIndex = 23;
            // 
            // studentidlb
            // 
            this.studentidlb.AutoSize = true;
            this.studentidlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentidlb.Location = new System.Drawing.Point(9, 25);
            this.studentidlb.Name = "studentidlb";
            this.studentidlb.Size = new System.Drawing.Size(114, 16);
            this.studentidlb.TabIndex = 0;
            this.studentidlb.Text = "Enter Instructor ID:";
            this.studentidlb.Click += new System.EventHandler(this.studentidlb_Click);
            // 
            // submitid
            // 
            this.submitid.Location = new System.Drawing.Point(178, 20);
            this.submitid.Name = "submitid";
            this.submitid.Size = new System.Drawing.Size(75, 23);
            this.submitid.TabIndex = 2;
            this.submitid.Text = "Enter";
            this.submitid.UseVisualStyleBackColor = true;
            this.submitid.Click += new System.EventHandler(this.submitid_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.fsnametb);
            this.groupBox6.Controls.Add(this.streettb);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Controls.Add(this.emailtb);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.officetb);
            this.groupBox6.Controls.Add(this.ziptb);
            this.groupBox6.Controls.Add(this.sidd);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.cnamelb);
            this.groupBox6.Controls.Add(this.sfnamelb);
            this.groupBox6.Controls.Add(this.streetlb);
            this.groupBox6.Controls.Add(this.studidlb);
            this.groupBox6.Controls.Add(this.officelb);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Controls.Add(this.citytb);
            this.groupBox6.Controls.Add(this.slnametb);
            this.groupBox6.Controls.Add(this.statetb);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(294, 28);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(265, 352);
            this.groupBox6.TabIndex = 29;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Instructor Info";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 16);
            this.label8.TabIndex = 28;
            this.label8.Text = "Zip :";
            // 
            // fsnametb
            // 
            this.fsnametb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fsnametb.Location = new System.Drawing.Point(67, 60);
            this.fsnametb.Name = "fsnametb";
            this.fsnametb.ShortcutsEnabled = false;
            this.fsnametb.Size = new System.Drawing.Size(186, 26);
            this.fsnametb.TabIndex = 3;
            // 
            // streettb
            // 
            this.streettb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.streettb.Location = new System.Drawing.Point(67, 131);
            this.streettb.Multiline = true;
            this.streettb.Name = "streettb";
            this.streettb.Size = new System.Drawing.Size(186, 26);
            this.streettb.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 16);
            this.label6.TabIndex = 27;
            this.label6.Text = "State :";
            // 
            // emailtb
            // 
            this.emailtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailtb.Location = new System.Drawing.Point(67, 272);
            this.emailtb.Name = "emailtb";
            this.emailtb.Size = new System.Drawing.Size(186, 26);
            this.emailtb.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 16);
            this.label7.TabIndex = 28;
            this.label7.Text = "City :";
            // 
            // officetb
            // 
            this.officetb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.officetb.Location = new System.Drawing.Point(67, 307);
            this.officetb.Name = "officetb";
            this.officetb.Size = new System.Drawing.Size(186, 26);
            this.officetb.TabIndex = 10;
            // 
            // ziptb
            // 
            this.ziptb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ziptb.Location = new System.Drawing.Point(67, 236);
            this.ziptb.Name = "ziptb";
            this.ziptb.Size = new System.Drawing.Size(186, 26);
            this.ziptb.TabIndex = 8;
            // 
            // sidd
            // 
            this.sidd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidd.Location = new System.Drawing.Point(67, 26);
            this.sidd.Name = "sidd";
            this.sidd.Size = new System.Drawing.Size(186, 26);
            this.sidd.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "Email:";
            // 
            // cnamelb
            // 
            this.cnamelb.AutoSize = true;
            this.cnamelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cnamelb.Location = new System.Drawing.Point(12, 100);
            this.cnamelb.Name = "cnamelb";
            this.cnamelb.Size = new System.Drawing.Size(39, 16);
            this.cnamelb.TabIndex = 19;
            this.cnamelb.Text = "Last :";
            // 
            // sfnamelb
            // 
            this.sfnamelb.AutoSize = true;
            this.sfnamelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sfnamelb.Location = new System.Drawing.Point(14, 66);
            this.sfnamelb.Name = "sfnamelb";
            this.sfnamelb.Size = new System.Drawing.Size(39, 16);
            this.sfnamelb.TabIndex = 5;
            this.sfnamelb.Text = "First :";
            // 
            // streetlb
            // 
            this.streetlb.AutoSize = true;
            this.streetlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.streetlb.Location = new System.Drawing.Point(14, 137);
            this.streetlb.Name = "streetlb";
            this.streetlb.Size = new System.Drawing.Size(49, 16);
            this.streetlb.TabIndex = 18;
            this.streetlb.Text = "Street :";
            // 
            // studidlb
            // 
            this.studidlb.AutoSize = true;
            this.studidlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studidlb.Location = new System.Drawing.Point(14, 32);
            this.studidlb.Name = "studidlb";
            this.studidlb.Size = new System.Drawing.Size(27, 16);
            this.studidlb.TabIndex = 4;
            this.studidlb.Text = "ID :";
            // 
            // officelb
            // 
            this.officelb.AutoSize = true;
            this.officelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.officelb.Location = new System.Drawing.Point(14, 313);
            this.officelb.Name = "officelb";
            this.officelb.Size = new System.Drawing.Size(48, 16);
            this.officelb.TabIndex = 16;
            this.officelb.Text = "Office :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(159, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 10;
            // 
            // citytb
            // 
            this.citytb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.citytb.Location = new System.Drawing.Point(67, 165);
            this.citytb.Name = "citytb";
            this.citytb.Size = new System.Drawing.Size(186, 26);
            this.citytb.TabIndex = 6;
            // 
            // slnametb
            // 
            this.slnametb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slnametb.Location = new System.Drawing.Point(67, 94);
            this.slnametb.Name = "slnametb";
            this.slnametb.Size = new System.Drawing.Size(186, 26);
            this.slnametb.TabIndex = 4;
            // 
            // statetb
            // 
            this.statetb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statetb.Location = new System.Drawing.Point(67, 200);
            this.statetb.Name = "statetb";
            this.statetb.Size = new System.Drawing.Size(186, 26);
            this.statetb.TabIndex = 7;
            // 
            // SectionLink
            // 
            this.SectionLink.AutoSize = true;
            this.SectionLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SectionLink.Location = new System.Drawing.Point(150, 8);
            this.SectionLink.Name = "SectionLink";
            this.SectionLink.Size = new System.Drawing.Size(53, 16);
            this.SectionLink.TabIndex = 37;
            this.SectionLink.TabStop = true;
            this.SectionLink.Text = "Section";
            this.SectionLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SectionLink_LinkClicked);
            // 
            // CoursesLink
            // 
            this.CoursesLink.AutoSize = true;
            this.CoursesLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoursesLink.Location = new System.Drawing.Point(219, 8);
            this.CoursesLink.Name = "CoursesLink";
            this.CoursesLink.Size = new System.Drawing.Size(58, 16);
            this.CoursesLink.TabIndex = 36;
            this.CoursesLink.TabStop = true;
            this.CoursesLink.Text = "Courses";
            this.CoursesLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CoursesLink_LinkClicked);
            // 
            // Studentlink
            // 
            this.Studentlink.AutoSize = true;
            this.Studentlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Studentlink.Location = new System.Drawing.Point(77, 8);
            this.Studentlink.Name = "Studentlink";
            this.Studentlink.Size = new System.Drawing.Size(53, 16);
            this.Studentlink.TabIndex = 35;
            this.Studentlink.TabStop = true;
            this.Studentlink.Text = "Student";
            this.Studentlink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Studentlink_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(22, 8);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(45, 16);
            this.linkLabel1.TabIndex = 34;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Home";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Studentidcb
            // 
            this.Studentidcb.FormattingEnabled = true;
            this.Studentidcb.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.Studentidcb.Location = new System.Drawing.Point(125, 17);
            this.Studentidcb.Name = "Studentidcb";
            this.Studentidcb.Size = new System.Drawing.Size(47, 24);
            this.Studentidcb.TabIndex = 38;
            // 
            // ResetAllFields
            // 
            this.ResetAllFields.AutoSize = true;
            this.ResetAllFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetAllFields.Location = new System.Drawing.Point(455, 8);
            this.ResetAllFields.Name = "ResetAllFields";
            this.ResetAllFields.Size = new System.Drawing.Size(92, 16);
            this.ResetAllFields.TabIndex = 44;
            this.ResetAllFields.TabStop = true;
            this.ResetAllFields.Text = "Clear all fields";
            this.ResetAllFields.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ResetAllFields_LinkClicked);
            // 
            // InstructorControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 403);
            this.Controls.Add(this.ResetAllFields);
            this.Controls.Add(this.SectionLink);
            this.Controls.Add(this.CoursesLink);
            this.Controls.Add(this.Studentlink);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.Name = "InstructorControl";
            this.Text = "InstructorControl";
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button dropC;
        private System.Windows.Forms.Label crn;
        private System.Windows.Forms.Label studentidlb;
        private System.Windows.Forms.Button submitid;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox fsnametb;
        private System.Windows.Forms.TextBox streettb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox emailtb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox officetb;
        private System.Windows.Forms.TextBox ziptb;
        private System.Windows.Forms.TextBox sidd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label cnamelb;
        private System.Windows.Forms.Label sfnamelb;
        private System.Windows.Forms.Label streetlb;
        private System.Windows.Forms.Label studidlb;
        private System.Windows.Forms.Label officelb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox citytb;
        private System.Windows.Forms.TextBox slnametb;
        private System.Windows.Forms.TextBox statetb;
        private System.Windows.Forms.LinkLabel SectionLink;
        private System.Windows.Forms.LinkLabel CoursesLink;
        private System.Windows.Forms.LinkLabel Studentlink;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.ComboBox Studentidcb;
        private System.Windows.Forms.LinkLabel ResetAllFields;
    }
}