﻿namespace RegistrationRon
{
    partial class SectionControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.crnstb = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dropC = new System.Windows.Forms.Button();
            this.crn = new System.Windows.Forms.Label();
            this.secidlb = new System.Windows.Forms.Label();
            this.submitid = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.idtb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.intemailtb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.instb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.crntb = new System.Windows.Forms.TextBox();
            this.tdaytb = new System.Windows.Forms.TextBox();
            this.roomnotb = new System.Windows.Forms.TextBox();
            this.cidtb = new System.Windows.Forms.TextBox();
            this.cidlb = new System.Windows.Forms.Label();
            this.credithourlb = new System.Windows.Forms.Label();
            this.deslb = new System.Windows.Forms.Label();
            this.coursenamelb = new System.Windows.Forms.Label();
            this.InstructorLink = new System.Windows.Forms.LinkLabel();
            this.CoursesLink = new System.Windows.Forms.LinkLabel();
            this.Studentlink = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.ResetAllFields = new System.Windows.Forms.LinkLabel();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.crnstb);
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.secidlb);
            this.groupBox4.Controls.Add(this.submitid);
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(2, 26);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(563, 361);
            this.groupBox4.TabIndex = 30;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Search";
            // 
            // crnstb
            // 
            this.crnstb.FormattingEnabled = true;
            this.crnstb.Items.AddRange(new object[] {
            "30101",
            "30102",
            "30103",
            "30104",
            "30105",
            "30106",
            "30107",
            "30108",
            "30109",
            "30110",
            "30112",
            "30113",
            "30114",
            "30115",
            "30116"});
            this.crnstb.Location = new System.Drawing.Point(121, 19);
            this.crnstb.Name = "crnstb";
            this.crnstb.Size = new System.Drawing.Size(92, 24);
            this.crnstb.TabIndex = 27;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.listBox1);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(301, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(274, 361);
            this.groupBox6.TabIndex = 33;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Sections";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(6, 30);
            this.listBox1.Name = "listBox1";
            this.listBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox1.Size = new System.Drawing.Size(253, 308);
            this.listBox1.TabIndex = 10;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.dropC);
            this.groupBox5.Controls.Add(this.crn);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(6, 188);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(289, 156);
            this.groupBox5.TabIndex = 32;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Actions";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(61, 64);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 37);
            this.button2.TabIndex = 25;
            this.button2.Text = "Update Section";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(61, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 37);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add Section";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dropC
            // 
            this.dropC.Location = new System.Drawing.Point(61, 107);
            this.dropC.Name = "dropC";
            this.dropC.Size = new System.Drawing.Size(153, 38);
            this.dropC.TabIndex = 24;
            this.dropC.Text = "Delete Section";
            this.dropC.UseVisualStyleBackColor = true;
            this.dropC.Click += new System.EventHandler(this.dropC_Click);
            // 
            // crn
            // 
            this.crn.AutoSize = true;
            this.crn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crn.Location = new System.Drawing.Point(19, 42);
            this.crn.Name = "crn";
            this.crn.Size = new System.Drawing.Size(0, 16);
            this.crn.TabIndex = 23;
            // 
            // secidlb
            // 
            this.secidlb.AutoSize = true;
            this.secidlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secidlb.Location = new System.Drawing.Point(41, 24);
            this.secidlb.Name = "secidlb";
            this.secidlb.Size = new System.Drawing.Size(75, 16);
            this.secidlb.TabIndex = 29;
            this.secidlb.Text = "Enter Crn #:";
            // 
            // submitid
            // 
            this.submitid.Location = new System.Drawing.Point(220, 19);
            this.submitid.Name = "submitid";
            this.submitid.Size = new System.Drawing.Size(75, 23);
            this.submitid.TabIndex = 31;
            this.submitid.Text = "Enter";
            this.submitid.UseVisualStyleBackColor = true;
            this.submitid.Click += new System.EventHandler(this.submitid_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.idtb);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.intemailtb);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.instb);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.crntb);
            this.groupBox2.Controls.Add(this.tdaytb);
            this.groupBox2.Controls.Add(this.roomnotb);
            this.groupBox2.Controls.Add(this.cidtb);
            this.groupBox2.Controls.Add(this.cidlb);
            this.groupBox2.Controls.Add(this.credithourlb);
            this.groupBox2.Controls.Add(this.deslb);
            this.groupBox2.Controls.Add(this.coursenamelb);
            this.groupBox2.Location = new System.Drawing.Point(6, 51);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(289, 140);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            // 
            // idtb
            // 
            this.idtb.Location = new System.Drawing.Point(82, 76);
            this.idtb.Name = "idtb";
            this.idtb.Size = new System.Drawing.Size(31, 22);
            this.idtb.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "Instructor ID :";
            // 
            // intemailtb
            // 
            this.intemailtb.Location = new System.Drawing.Point(115, 105);
            this.intemailtb.Name = "intemailtb";
            this.intemailtb.Size = new System.Drawing.Size(168, 22);
            this.intemailtb.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Instructor Email:";
            // 
            // instb
            // 
            this.instb.Location = new System.Drawing.Point(167, 76);
            this.instb.Name = "instb";
            this.instb.Size = new System.Drawing.Size(116, 22);
            this.instb.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(119, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 16);
            this.label1.TabIndex = 20;
            this.label1.Text = "Name :";
            // 
            // crntb
            // 
            this.crntb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crntb.Location = new System.Drawing.Point(61, 12);
            this.crntb.Name = "crntb";
            this.crntb.Size = new System.Drawing.Size(56, 22);
            this.crntb.TabIndex = 2;
            // 
            // tdaytb
            // 
            this.tdaytb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tdaytb.Location = new System.Drawing.Point(191, 44);
            this.tdaytb.Name = "tdaytb";
            this.tdaytb.ShortcutsEnabled = false;
            this.tdaytb.Size = new System.Drawing.Size(92, 22);
            this.tdaytb.TabIndex = 3;
            // 
            // roomnotb
            // 
            this.roomnotb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomnotb.Location = new System.Drawing.Point(52, 46);
            this.roomnotb.Name = "roomnotb";
            this.roomnotb.Size = new System.Drawing.Size(61, 22);
            this.roomnotb.TabIndex = 4;
            // 
            // cidtb
            // 
            this.cidtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cidtb.Location = new System.Drawing.Point(208, 11);
            this.cidtb.Multiline = true;
            this.cidtb.Name = "cidtb";
            this.cidtb.Size = new System.Drawing.Size(75, 22);
            this.cidtb.TabIndex = 5;
            // 
            // cidlb
            // 
            this.cidlb.AutoSize = true;
            this.cidlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cidlb.Location = new System.Drawing.Point(0, 15);
            this.cidlb.Name = "cidlb";
            this.cidlb.Size = new System.Drawing.Size(43, 16);
            this.cidlb.TabIndex = 4;
            this.cidlb.Text = "CRN :";
            // 
            // credithourlb
            // 
            this.credithourlb.AutoSize = true;
            this.credithourlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.credithourlb.Location = new System.Drawing.Point(129, 15);
            this.credithourlb.Name = "credithourlb";
            this.credithourlb.Size = new System.Drawing.Size(73, 16);
            this.credithourlb.TabIndex = 18;
            this.credithourlb.Text = "Course ID :";
            this.credithourlb.Click += new System.EventHandler(this.credithourlb_Click);
            // 
            // deslb
            // 
            this.deslb.AutoSize = true;
            this.deslb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deslb.Location = new System.Drawing.Point(2, 51);
            this.deslb.Name = "deslb";
            this.deslb.Size = new System.Drawing.Size(51, 16);
            this.deslb.TabIndex = 19;
            this.deslb.Text = "Room :";
            // 
            // coursenamelb
            // 
            this.coursenamelb.AutoSize = true;
            this.coursenamelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coursenamelb.Location = new System.Drawing.Point(112, 49);
            this.coursenamelb.Name = "coursenamelb";
            this.coursenamelb.Size = new System.Drawing.Size(80, 16);
            this.coursenamelb.TabIndex = 5;
            this.coursenamelb.Text = "Time Days :";
            // 
            // InstructorLink
            // 
            this.InstructorLink.AutoSize = true;
            this.InstructorLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructorLink.Location = new System.Drawing.Point(132, 7);
            this.InstructorLink.Name = "InstructorLink";
            this.InstructorLink.Size = new System.Drawing.Size(61, 16);
            this.InstructorLink.TabIndex = 41;
            this.InstructorLink.TabStop = true;
            this.InstructorLink.Text = "Instructor";
            this.InstructorLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SectionLink_LinkClicked);
            // 
            // CoursesLink
            // 
            this.CoursesLink.AutoSize = true;
            this.CoursesLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoursesLink.Location = new System.Drawing.Point(205, 7);
            this.CoursesLink.Name = "CoursesLink";
            this.CoursesLink.Size = new System.Drawing.Size(58, 16);
            this.CoursesLink.TabIndex = 40;
            this.CoursesLink.TabStop = true;
            this.CoursesLink.Text = "Courses";
            this.CoursesLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CoursesLink_LinkClicked);
            // 
            // Studentlink
            // 
            this.Studentlink.AutoSize = true;
            this.Studentlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Studentlink.Location = new System.Drawing.Point(63, 7);
            this.Studentlink.Name = "Studentlink";
            this.Studentlink.Size = new System.Drawing.Size(53, 16);
            this.Studentlink.TabIndex = 39;
            this.Studentlink.TabStop = true;
            this.Studentlink.Text = "Student";
            this.Studentlink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Studentlink_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(8, 7);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(45, 16);
            this.linkLabel1.TabIndex = 38;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Home";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // ResetAllFields
            // 
            this.ResetAllFields.AutoSize = true;
            this.ResetAllFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetAllFields.Location = new System.Drawing.Point(469, 9);
            this.ResetAllFields.Name = "ResetAllFields";
            this.ResetAllFields.Size = new System.Drawing.Size(96, 16);
            this.ResetAllFields.TabIndex = 42;
            this.ResetAllFields.TabStop = true;
            this.ResetAllFields.Text = "Reset all fields";
            this.ResetAllFields.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ResetAllFields_LinkClicked);
            // 
            // SectionControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 403);
            this.Controls.Add(this.ResetAllFields);
            this.Controls.Add(this.InstructorLink);
            this.Controls.Add(this.CoursesLink);
            this.Controls.Add(this.Studentlink);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.groupBox4);
            this.Name = "SectionControl";
            this.Text = "Sections";
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label secidlb;
        private System.Windows.Forms.Button submitid;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox crntb;
        private System.Windows.Forms.TextBox tdaytb;
        private System.Windows.Forms.TextBox roomnotb;
        private System.Windows.Forms.TextBox cidtb;
        private System.Windows.Forms.Label cidlb;
        private System.Windows.Forms.Label credithourlb;
        private System.Windows.Forms.Label deslb;
        private System.Windows.Forms.Label coursenamelb;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button dropC;
        private System.Windows.Forms.Label crn;
        private System.Windows.Forms.TextBox instb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox intemailtb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idtb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.LinkLabel InstructorLink;
        private System.Windows.Forms.LinkLabel CoursesLink;
        private System.Windows.Forms.LinkLabel Studentlink;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel ResetAllFields;
        private System.Windows.Forms.ComboBox crnstb;
    }
}