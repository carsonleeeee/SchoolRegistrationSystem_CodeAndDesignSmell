﻿namespace RegistrationRon
{
    partial class CourseControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.studentidlb = new System.Windows.Forms.Label();
            this.Courseidtb = new System.Windows.Forms.TextBox();
            this.submitid = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cidtb = new System.Windows.Forms.TextBox();
            this.cnametb = new System.Windows.Forms.TextBox();
            this.destb = new System.Windows.Forms.TextBox();
            this.chtb = new System.Windows.Forms.TextBox();
            this.cidlb = new System.Windows.Forms.Label();
            this.credithourlb = new System.Windows.Forms.Label();
            this.deslb = new System.Windows.Forms.Label();
            this.coursenamelb = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dropC = new System.Windows.Forms.Button();
            this.crn = new System.Windows.Forms.Label();
            this.SectionLink = new System.Windows.Forms.LinkLabel();
            this.InstructorLink = new System.Windows.Forms.LinkLabel();
            this.Studentlink = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.studentidlb);
            this.groupBox4.Controls.Add(this.Courseidtb);
            this.groupBox4.Controls.Add(this.submitid);
            this.groupBox4.Controls.Add(this.groupBox1);
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 30);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(544, 352);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Search";
            // 
            // studentidlb
            // 
            this.studentidlb.AutoSize = true;
            this.studentidlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentidlb.Location = new System.Drawing.Point(21, 29);
            this.studentidlb.Name = "studentidlb";
            this.studentidlb.Size = new System.Drawing.Size(104, 16);
            this.studentidlb.TabIndex = 29;
            this.studentidlb.Text = "Enter Course ID:";
            // 
            // Courseidtb
            // 
            this.Courseidtb.Location = new System.Drawing.Point(131, 23);
            this.Courseidtb.Name = "Courseidtb";
            this.Courseidtb.Size = new System.Drawing.Size(73, 22);
            this.Courseidtb.TabIndex = 30;
            this.Courseidtb.Text = "cist";
            // 
            // submitid
            // 
            this.submitid.Location = new System.Drawing.Point(222, 21);
            this.submitid.Name = "submitid";
            this.submitid.Size = new System.Drawing.Size(75, 23);
            this.submitid.TabIndex = 31;
            this.submitid.Text = "Enter";
            this.submitid.UseVisualStyleBackColor = true;
            this.submitid.Click += new System.EventHandler(this.submitid_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(8, 160);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(530, 186);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Available Courses";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(7, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox1.Size = new System.Drawing.Size(517, 164);
            this.listBox1.TabIndex = 9;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cidtb);
            this.groupBox2.Controls.Add(this.cnametb);
            this.groupBox2.Controls.Add(this.destb);
            this.groupBox2.Controls.Add(this.chtb);
            this.groupBox2.Controls.Add(this.cidlb);
            this.groupBox2.Controls.Add(this.credithourlb);
            this.groupBox2.Controls.Add(this.deslb);
            this.groupBox2.Controls.Add(this.coursenamelb);
            this.groupBox2.Location = new System.Drawing.Point(15, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(300, 112);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            // 
            // cidtb
            // 
            this.cidtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cidtb.Location = new System.Drawing.Point(57, 21);
            this.cidtb.Name = "cidtb";
            this.cidtb.Size = new System.Drawing.Size(69, 22);
            this.cidtb.TabIndex = 2;
            // 
            // cnametb
            // 
            this.cnametb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cnametb.Location = new System.Drawing.Point(57, 49);
            this.cnametb.Name = "cnametb";
            this.cnametb.ShortcutsEnabled = false;
            this.cnametb.Size = new System.Drawing.Size(225, 22);
            this.cnametb.TabIndex = 3;
            // 
            // destb
            // 
            this.destb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.destb.Location = new System.Drawing.Point(57, 77);
            this.destb.Name = "destb";
            this.destb.Size = new System.Drawing.Size(225, 22);
            this.destb.TabIndex = 4;
            // 
            // chtb
            // 
            this.chtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chtb.Location = new System.Drawing.Point(237, 17);
            this.chtb.Multiline = true;
            this.chtb.Name = "chtb";
            this.chtb.Size = new System.Drawing.Size(45, 26);
            this.chtb.TabIndex = 5;
            // 
            // cidlb
            // 
            this.cidlb.AutoSize = true;
            this.cidlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cidlb.Location = new System.Drawing.Point(25, 24);
            this.cidlb.Name = "cidlb";
            this.cidlb.Size = new System.Drawing.Size(27, 16);
            this.cidlb.TabIndex = 4;
            this.cidlb.Text = "ID :";
            // 
            // credithourlb
            // 
            this.credithourlb.AutoSize = true;
            this.credithourlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.credithourlb.Location = new System.Drawing.Point(146, 24);
            this.credithourlb.Name = "credithourlb";
            this.credithourlb.Size = new System.Drawing.Size(85, 16);
            this.credithourlb.TabIndex = 18;
            this.credithourlb.Text = "Credit Hours:";
            // 
            // deslb
            // 
            this.deslb.AutoSize = true;
            this.deslb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deslb.Location = new System.Drawing.Point(6, 80);
            this.deslb.Name = "deslb";
            this.deslb.Size = new System.Drawing.Size(46, 16);
            this.deslb.TabIndex = 19;
            this.deslb.Text = "Desc :";
            // 
            // coursenamelb
            // 
            this.coursenamelb.AutoSize = true;
            this.coursenamelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coursenamelb.Location = new System.Drawing.Point(4, 52);
            this.coursenamelb.Name = "coursenamelb";
            this.coursenamelb.Size = new System.Drawing.Size(48, 16);
            this.coursenamelb.TabIndex = 5;
            this.coursenamelb.Text = "Name:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.dropC);
            this.groupBox5.Controls.Add(this.crn);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(355, 33);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(201, 157);
            this.groupBox5.TabIndex = 27;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Actions";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(22, 64);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 37);
            this.button2.TabIndex = 25;
            this.button2.Text = "Update Course";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(22, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 38);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add Course";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dropC
            // 
            this.dropC.Location = new System.Drawing.Point(22, 109);
            this.dropC.Name = "dropC";
            this.dropC.Size = new System.Drawing.Size(153, 35);
            this.dropC.TabIndex = 24;
            this.dropC.Text = "Delete Course";
            this.dropC.UseVisualStyleBackColor = true;
            this.dropC.Click += new System.EventHandler(this.dropC_Click);
            // 
            // crn
            // 
            this.crn.AutoSize = true;
            this.crn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crn.Location = new System.Drawing.Point(19, 42);
            this.crn.Name = "crn";
            this.crn.Size = new System.Drawing.Size(0, 16);
            this.crn.TabIndex = 23;
            // 
            // SectionLink
            // 
            this.SectionLink.AutoSize = true;
            this.SectionLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SectionLink.Location = new System.Drawing.Point(152, 9);
            this.SectionLink.Name = "SectionLink";
            this.SectionLink.Size = new System.Drawing.Size(53, 16);
            this.SectionLink.TabIndex = 41;
            this.SectionLink.TabStop = true;
            this.SectionLink.Text = "Section";
            this.SectionLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SectionLink_LinkClicked);
            // 
            // InstructorLink
            // 
            this.InstructorLink.AutoSize = true;
            this.InstructorLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructorLink.Location = new System.Drawing.Point(221, 9);
            this.InstructorLink.Name = "InstructorLink";
            this.InstructorLink.Size = new System.Drawing.Size(61, 16);
            this.InstructorLink.TabIndex = 40;
            this.InstructorLink.TabStop = true;
            this.InstructorLink.Text = "Instructor";
            this.InstructorLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.InstructorLink_LinkClicked);
            // 
            // Studentlink
            // 
            this.Studentlink.AutoSize = true;
            this.Studentlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Studentlink.Location = new System.Drawing.Point(79, 9);
            this.Studentlink.Name = "Studentlink";
            this.Studentlink.Size = new System.Drawing.Size(53, 16);
            this.Studentlink.TabIndex = 39;
            this.Studentlink.TabStop = true;
            this.Studentlink.Text = "Student";
            this.Studentlink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Studentlink_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(24, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(45, 16);
            this.linkLabel1.TabIndex = 38;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Home";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // CourseControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 403);
            this.Controls.Add(this.SectionLink);
            this.Controls.Add(this.InstructorLink);
            this.Controls.Add(this.Studentlink);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Name = "CourseControl";
            this.Text = "CourseControl";
            this.Load += new System.EventHandler(this.CourseControl_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button dropC;
        private System.Windows.Forms.Label crn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox cnametb;
        private System.Windows.Forms.TextBox chtb;
        private System.Windows.Forms.TextBox cidtb;
        private System.Windows.Forms.Label deslb;
        private System.Windows.Forms.Label coursenamelb;
        private System.Windows.Forms.Label credithourlb;
        private System.Windows.Forms.Label cidlb;
        private System.Windows.Forms.TextBox destb;
        private System.Windows.Forms.Label studentidlb;
        private System.Windows.Forms.TextBox Courseidtb;
        private System.Windows.Forms.Button submitid;
        private System.Windows.Forms.LinkLabel SectionLink;
        private System.Windows.Forms.LinkLabel InstructorLink;
        private System.Windows.Forms.LinkLabel Studentlink;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}